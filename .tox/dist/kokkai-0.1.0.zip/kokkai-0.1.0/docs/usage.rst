=====
Usage
=====

To use kokkai in a project::

    import kokkai
