"""Top-level package for kokkai."""

__author__ = """shimakaze_soft"""
__email__ = 'audreyr@example.com'
__version__ = '0.1.0'
