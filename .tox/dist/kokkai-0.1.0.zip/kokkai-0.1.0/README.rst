======
kokkai
======


.. image:: https://img.shields.io/pypi/v/kokkai.svg
        :target: https://pypi.python.org/pypi/kokkai

.. image:: https://img.shields.io/travis/shimakaze-git/kokkai.svg
        :target: https://travis-ci.com/shimakaze-git/kokkai

.. image:: https://readthedocs.org/projects/kokkai/badge/?version=latest
        :target: https://kokkai.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status


.. image:: https://pyup.io/repos/github/shimakaze-git/kokkai/shield.svg
     :target: https://pyup.io/repos/github/shimakaze-git/kokkai/
     :alt: Updates

* https://qiita.com/kenta1984/items/1acfddb3d920a11e6c8b

* 国会での発言回数
* 国会での発言内容
* 政治家相関関係

Python Boilerplate contains all the boilerplate you need to create a Python package.


* Free software: MIT license
* Documentation: https://kokkai.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
