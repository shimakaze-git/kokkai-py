"""Unit test package for kokkai."""
